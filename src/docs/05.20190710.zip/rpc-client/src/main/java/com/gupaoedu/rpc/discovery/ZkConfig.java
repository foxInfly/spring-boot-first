package com.gupaoedu.rpc.discovery;

public class ZkConfig {

    public static String CONNECTION_STR="192.168.13.102:2181,192.168.13.103:2181,192.168.13.104:2181";



}
