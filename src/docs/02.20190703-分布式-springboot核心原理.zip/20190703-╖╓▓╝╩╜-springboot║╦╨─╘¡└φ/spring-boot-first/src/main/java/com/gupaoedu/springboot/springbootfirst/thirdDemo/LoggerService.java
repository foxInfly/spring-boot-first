package com.gupaoedu.springboot.springbootfirst.thirdDemo;

public class LoggerService {
}
