package com.gupaoedu.springboot.springbootfirst.secondDemo.other;


public class OtherBean {

}
