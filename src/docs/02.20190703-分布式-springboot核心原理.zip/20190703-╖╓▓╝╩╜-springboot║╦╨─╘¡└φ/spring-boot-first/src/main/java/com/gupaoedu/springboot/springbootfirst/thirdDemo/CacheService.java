package com.gupaoedu.springboot.springbootfirst.thirdDemo;

public class CacheService {
}
