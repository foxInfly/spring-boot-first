package com.gupaoedu.springboot.springbootfirst.secondDemo.current;

public class DefaultBean {


}
