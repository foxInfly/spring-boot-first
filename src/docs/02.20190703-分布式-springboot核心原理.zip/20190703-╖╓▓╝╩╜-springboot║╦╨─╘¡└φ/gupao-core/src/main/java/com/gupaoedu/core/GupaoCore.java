package com.gupaoedu.core;

public class GupaoCore {

    public String study(){
        System.out.println("good good study, day day up");
        return "GupaoeEdu.com";
    }
}
